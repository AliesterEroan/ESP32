#include <WiFi.h>
#include <PubSubClient.h>
#include "DHT.h"

// --- Configuration ---
const char* ssid     = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "test.mosquitto.org"; 
const int mqtt_port   = 1883;

// --- Pin Definitions ---
#define DHTPIN 4
#define DHTTYPE DHT22

const int LED_R_PIN = 12; // LED Rouge
const int LED_G_PIN = 14; // LED Verte

// --- MQTT Topics ---
const char* topic_dht   = "iot/formagerie/esp32/dht22";
const char* topic_led_r = "iot/formagerie/esp32/led_R";
const char* topic_led_g = "iot/formagerie/esp32/led_G";

// --- Object Initializations ---
DHT dht(DHTPIN, DHTTYPE);
WiFiClient espClient;
PubSubClient client(espClient);

unsigned long lastMsgTime = 0;
const unsigned long interval = 5000; 

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connexion à ");
  Serial.println(ssid);

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connecté !");
  Serial.print("Adresse IP : ");
  Serial.println(WiFi.localIP());
}

// 🛠️ AJOUTÉ : Cette fonction intercepte les ordres envoyés par Python/SCADA
void callback(char* topic, byte* payload, unsigned length) {
  Serial.print("Message reçu sur le topic [");
  Serial.print(topic);
  Serial.print("] : ");
  
  // Conversion du payload en chaîne de caractères
  String message = "";
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  Serial.println(message);

  // Analyse du topic ciblé et application de l'état physique
  if (String(topic) == topic_led_r) {
    if (message == "on" || message == "1") {
      digitalWrite(LED_R_PIN, HIGH);
    } else {
      digitalWrite(LED_R_PIN, LOW);
    }
  } 
  else if (String(topic) == topic_led_g) {
    if (message == "on" || message == "1") {
      digitalWrite(LED_G_PIN, HIGH);
    } else {
      digitalWrite(LED_G_PIN, LOW);
    }
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Tentative de connexion MQTT...");
    String clientId = "ESP32Client-" + String(random(0xffff), HEX);
    
    if (client.connect(clientId.c_str())) {
      Serial.println("connecté !");
      
      // 🛠️ AJOUTÉ : L'ESP32 s'abonne désormais aux topics d'ordres des LEDs
      client.subscribe(topic_led_r);
      client.subscribe(topic_led_g);
      Serial.println("Abonnements aux topics LED activés.");
    } else {
      Serial.print("échec, rc=");
      Serial.print(client.state());
      Serial.println(" nouvelle tentative dans 5 secondes");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  pinMode(LED_R_PIN, OUTPUT);
  pinMode(LED_G_PIN, OUTPUT);
  
  // Par sécurité au démarrage, on éteint tout
  digitalWrite(LED_R_PIN, LOW);
  digitalWrite(LED_G_PIN, HIGH); // Système initialisé OK au début
  
  dht.begin();
  setup_wifi();
  
  client.setServer(mqtt_server, mqtt_port);
  // 🛠️ AJOUTÉ : Liaison de la fonction de réception MQTT
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop(); // Traite les messages MQTT entrants

  unsigned long now = millis();
  if (now - lastMsgTime > interval) {
    lastMsgTime = now;

    // Lecture et Envoi DHT22
    float h = dht.readHumidity();
    float t = dht.readTemperature();

    if (isnan(h) || isnan(t)) {
      Serial.println("Erreur de lecture du capteur DHT!");
    } else {
      String dhtPayload = "{\"temperature\":" + String(t, 2) + ",\"humidity\":" + String(h, 2) + "}";
      client.publish(topic_dht, dhtPayload.c_str());
      Serial.print("Published DHT: ");
      Serial.println(dhtPayload);
    }
  }
}